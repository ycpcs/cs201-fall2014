package edu.ycp.cs201.exam2;

public class Q7 {
	public static int sumOfDigits(int n) {
		// TODO
		
		return -1; // replace this
	}
}

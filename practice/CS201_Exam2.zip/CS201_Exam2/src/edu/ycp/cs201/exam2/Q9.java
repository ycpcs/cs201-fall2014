package edu.ycp.cs201.exam2;

import java.util.Scanner;

public class Q9 {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		// TODO: add any needed variables
		
		boolean done = false;
		while (!done) {
			// Read a line of input
			String line = keyboard.nextLine();
			
			if (line.trim().equals("quit")) {
				// Terminate the loop
				done = true;
			} else {
				// TODO: create a LineItem, add it to a collection
				
			}
		}
		
		// TODO: print out name and total cost for least and most expensive line items
	}
}

package edu.ycp.cs201.exam2;

public class LineItem {
	// TODO: add fields
	
	public LineItem(String name, int quantity, double unitPrice) {
		// TODO
	}
	
	public String getName() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	public int getQuantity() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	public double getUnitPrice() {
		throw new UnsupportedOperationException("TODO - implement");
	}
}

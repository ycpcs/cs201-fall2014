package edu.ycp.cs201.finalexam;

public class Rule110 {
	private static final int NCELLS = 12;

	public static void main(String[] args) {
		// Create initial generation
		Cell[] current = new Cell[NCELLS];
		for (int i = 0; i < current.length; i++) {
			current[i] = new Cell(i == NCELLS-2);
		}
		
		for (int i = 0; i < 10; i++) {
			// Print current generation
			printGen(current);
			
			// Compute next generation
			Cell[] next = new Cell[NCELLS];
			next[0] = new Cell(false);
			for (int j = 1; j <= NCELLS-2; j++) {
				next[j] = current[j].computeNext(current[j-1], current[j+1]);
			}
			next[NCELLS-1] = new Cell(false);
			
			current = next;
		}
	}

	private static void printGen(Cell[] current) {
		for (Cell c : current) {
			if (c.isAlive()) {
				System.out.print("*");
			} else {
				System.out.print(".");
			}
		}
		System.out.println();
	}
}

package edu.ycp.cs201.finalexam;

public class Q10 {
	public static int hexToInt(String s) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}

package edu.ycp.cs201.finalexam;

import java.util.List;

public class Q11 {
	public static<E extends Comparable<E>> boolean hasDuplicates(List<E> list) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}

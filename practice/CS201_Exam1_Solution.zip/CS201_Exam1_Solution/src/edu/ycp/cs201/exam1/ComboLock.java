package edu.ycp.cs201.exam1;

public class ComboLock {
	private int[] combo;
	private int spinCount;
	private int numCorrect;
	
	public ComboLock(int a, int b, int c) {
		combo = new int[3];
		combo[0] = a;
		combo[1] = b;
		combo[2] = c;
		spinCount = 0;
		numCorrect = 0;
	}
	
	public void spin(int x) {
		if (spinCount < combo.length) {
			if (x == combo[spinCount]) {
				numCorrect++;
			}
			spinCount++;
		}
	}
	
	public boolean isUnlocked() {
		return numCorrect == 3;
	}
}

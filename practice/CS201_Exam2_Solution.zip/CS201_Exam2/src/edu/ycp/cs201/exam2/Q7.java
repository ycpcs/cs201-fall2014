package edu.ycp.cs201.exam2;

public class Q7 {
	public static int sumOfDigits(int n) {
		if (n < 10) {
			return n;
		} else {
			return sumOfDigits(n/10) + (n%10);
		}
	}
}

package edu.ycp.cs201.exam2;

public class Q8 {
	public static String intToString(int n) {
		if (n < 10) {
			return "" + n;
		} else {
			return "" + intToString(n/10) + (char)((n%10)+'0'); 
		}
	}
}

package edu.ycp.cs201.exam2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q9 {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		// Use a list to store the LineItems
		List<LineItem> items = new ArrayList<LineItem>();
		
		boolean done = false;
		while (!done) {
			// Read a line of input
			String line = keyboard.nextLine();
			
			if (line.trim().equals("quit")) {
				// Terminate the loop
				done = true;
			} else {
				// Create a LineItem, add it to a collection
				String[] parts = line.split(",");
				LineItem lineItem = new LineItem(parts[0], Integer.parseInt(parts[1]), Double.parseDouble(parts[2]));
				items.add(lineItem);
			}
		}
		
		// Start out by assuming that the first item is the least and most expensive
		LineItem min = items.get(0), max = items.get(0);
		for (LineItem item : items) {
			if (totalPrice(item) < totalPrice(min)) {
				min = item;
			}
			if (totalPrice(item) > totalPrice(max)) {
				max = item;
			}
		}
		
		System.out.printf("Least expensive item: %s, total=%.2f\n", min.getName(), totalPrice(min));
		System.out.printf("Most expensive item: %s, total=%.2f\n", max.getName(), totalPrice(max));
	}

	private static double totalPrice(LineItem item) {
		return item.getUnitPrice() * item.getQuantity();
	}
}

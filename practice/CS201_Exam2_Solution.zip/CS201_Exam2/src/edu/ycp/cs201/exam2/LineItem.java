package edu.ycp.cs201.exam2;

public class LineItem {
	// TODO: add fields
	
	private String name;
	private int quantity;
	private double unitPrice;

	public LineItem(String name, int quantity, double unitPrice) {
		this.name = name;
		this.quantity = quantity;
		this.unitPrice = unitPrice;
	}
	
	public String getName() {
		return name;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public double getUnitPrice() {
		return unitPrice;
	}
}

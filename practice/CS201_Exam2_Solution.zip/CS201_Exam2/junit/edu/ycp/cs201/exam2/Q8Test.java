package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q8Test {
	@Test
	public void test0() {
		assertEquals("0", Q8.intToString(0));
	}
	
	@Test
	public void test4() {
		assertEquals("4", Q8.intToString(4));
	}
	
	@Test
	public void test1331() {
		assertEquals("1331", Q8.intToString(1331));
	}
	
	@Test
	public void test8675309() {
		assertEquals("8675309", Q8.intToString(8675309));
	}
}

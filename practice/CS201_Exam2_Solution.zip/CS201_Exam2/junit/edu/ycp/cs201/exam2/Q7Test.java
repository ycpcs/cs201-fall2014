package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q7Test {
	@Test
	public void test0() {
		assertEquals(0, Q7.sumOfDigits(0));
	}
	
	@Test
	public void test1() {
		assertEquals(1, Q7.sumOfDigits(1));
	}
	
	@Test
	public void test12() {
		assertEquals(3, Q7.sumOfDigits(12));
	}
	
	@Test
	public void test808() {
		assertEquals(16, Q7.sumOfDigits(808));
	}
	
	@Test
	public void test91025() {
		assertEquals(17, Q7.sumOfDigits(90125));
	}
}

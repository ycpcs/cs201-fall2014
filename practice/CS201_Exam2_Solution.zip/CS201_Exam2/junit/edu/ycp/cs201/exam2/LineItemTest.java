package edu.ycp.cs201.exam2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class LineItemTest {
	private static final double DELTA = 0.0000001;
	
	private LineItem applesItem;
	private LineItem orangesItem;
	
	@Before
	public void setUp() {
		applesItem = new LineItem("apples", 10, 0.50);
		orangesItem = new LineItem("oranges", 6, 0.60);
	}
	
	@Test
	public void testGetName() {
		assertEquals("apples", applesItem.getName());
		assertEquals("oranges", orangesItem.getName());
	}
	
	@Test
	public void testGetQuantity() {
		assertEquals(10, applesItem.getQuantity());
		assertEquals(6, orangesItem.getQuantity());
	}
	
	@Test
	public void testGetUnitPrice() {
		assertEquals(0.50, applesItem.getUnitPrice(), DELTA);
		assertEquals(0.60, orangesItem.getUnitPrice(), DELTA);
	}
}

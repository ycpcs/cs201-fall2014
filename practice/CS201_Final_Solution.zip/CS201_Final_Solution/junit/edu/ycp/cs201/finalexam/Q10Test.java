package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class Q10Test {
	@Test
	public void testZero() {
		assertEquals(0, Q10.hexToInt("0"));
	}
	
	@Test
	public void testFour() {
		assertEquals(4, Q10.hexToInt("4"));
	}

	@Test
	public void testC() {
		assertEquals(12, Q10.hexToInt("C"));
	}

	@Test
	public void test2C3() {
		assertEquals(707, Q10.hexToInt("2C3"));
	}
}

package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class Q11Test {
	private List<String> stringListWithDups;
	private List<String> stringListNoDups;
	private List<Integer> intListWithDups;
	private List<Integer> intListNoDups;
	
	@Before
	public void setUp() {
		stringListWithDups = Arrays.asList("C", "D", "E", "I", "E", "G", "G", "J", "I", "H");
		stringListNoDups = Arrays.asList("L", "K", "I", "Z", "S", "R", "N", "M", "C");
		intListWithDups = Arrays.asList(14, 12, 18, 29, 13, 24, 29, 30, 23, 14);
		intListNoDups = Arrays.asList(39, 18, 5, 24, 13, 27, 30, 8, 17, 19);
	}
	
	@Test
	public void test1() {
		assertTrue(Q11.hasDuplicates(stringListWithDups));
	}
	
	@Test
	public void test2() {
		assertFalse(Q11.hasDuplicates(stringListNoDups));
	}
	
	@Test
	public void test3() {
		assertTrue(Q11.hasDuplicates(intListWithDups));
	}
	
	@Test
	public void test4() {
		assertFalse(Q11.hasDuplicates(intListNoDups));
	}
}

package edu.ycp.cs201.finalexam;

import static org.junit.Assert.*;

import org.junit.Test;

public class CellTest {
	
	@Test
	public void testConstructorAndIsAlive() {
		Cell a = new Cell(false);
		Cell b = new Cell(true);
		
		assertFalse(a.isAlive());
		assertTrue(b.isAlive());
	}
	
	@Test
	public void testCase0() {
		Cell left = new Cell(false), middle = new Cell(false), right = new Cell(false);
		assertFalse(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase1() {
		Cell left = new Cell(false), middle = new Cell(false), right = new Cell(true);
		assertTrue(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase2() {
		Cell left = new Cell(false), middle = new Cell(true), right = new Cell(false);
		assertTrue(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase3() {
		Cell left = new Cell(false), middle = new Cell(true), right = new Cell(true);
		assertTrue(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase4() {
		Cell left = new Cell(true), middle = new Cell(false), right = new Cell(false);
		assertFalse(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase5() {
		Cell left = new Cell(true), middle = new Cell(false), right = new Cell(true);
		assertTrue(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase6() {
		Cell left = new Cell(true), middle = new Cell(true), right = new Cell(false);
		assertTrue(middle.computeNext(left, right).isAlive());
	}

	@Test
	public void testCase7() {
		Cell left = new Cell(true), middle = new Cell(true), right = new Cell(true);
		assertFalse(middle.computeNext(left, right).isAlive());
	}
}

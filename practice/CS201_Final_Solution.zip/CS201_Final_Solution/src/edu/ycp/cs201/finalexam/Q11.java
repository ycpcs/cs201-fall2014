package edu.ycp.cs201.finalexam;

import java.util.List;
import java.util.TreeSet;

public class Q11 {
	public static<E extends Comparable<E>> boolean hasDuplicates(List<E> list) {
		TreeSet<E> s = new TreeSet<E>();
		
		// Add all elements of list to s: this is O(N log N)
		s.addAll(list);
		
		// If the set contains fewer elements than the list,
		// there must be duplicate values in the list
		return s.size() < list.size();
	}
}

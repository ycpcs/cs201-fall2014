package edu.ycp.cs201.finalexam;

public class Cell {
	private boolean alive;

	public Cell(boolean b) {
		this.alive = b;
	}

	public boolean isAlive() {
		return this.alive;
	}

	public Cell computeNext(Cell left, Cell right) {
		boolean l = left.isAlive(), me = this.isAlive(), r = right.isAlive();
		
		boolean next = true;
		if (!l && !me && !r) {
			next = false;
		} else if (l && !me && !r) {
			next = false;
		} else if (l && me && r) {
			next = false;
		}
		
		return new Cell(next);
	}
}

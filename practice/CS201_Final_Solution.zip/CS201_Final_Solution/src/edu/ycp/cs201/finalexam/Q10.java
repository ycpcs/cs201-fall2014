package edu.ycp.cs201.finalexam;

public class Q10 {
	public static int hexToInt(String s) {
		// Base case
		if (s.equals("")) {
			return 0;
		}
		
		// Determine the numeric value of the last digit
		int val;
		char last = s.charAt(s.length() - 1);
		if (last >= '0' && last <= '9') {
			// last character is a decimal digit
			val = last - '0';
		} else {
			// last character is a hex digit
			val = "ABCDEF".indexOf(last) + 10;
		}
		
		// Use the substring with everything but the last
		// character as a subproblem
		String subprob = s.substring(0, s.length() - 1);
		
		// Solve the subproblem
		int subprobSoln = hexToInt(subprob);
		
		// Extend the solution to the subproblem
		return subprobSoln*16 + val;
	}
}

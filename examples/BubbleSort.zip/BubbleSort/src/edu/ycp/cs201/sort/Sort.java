package edu.ycp.cs201.sort;

import java.util.Collections;
import java.util.Comparator;

public class Sort {
	// World's worst sorting algorithm
	public static<E extends Comparable<E>> void bubbleSort(E[] arr) {
		for (int j = arr.length-1; j >= 0; j--) {
			for (int i = 0; i < j; i++) {
				if (arr[i].compareTo(arr[i+1]) > 0) {
					E tmp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = tmp;
				}
			}
		}
	}
	
	public static<E> void bubbleSort(E[] arr, Comparator<E> comp) {
		for (int j = arr.length-1; j >= 0; j--) {
			for (int i = 0; i < j; i++) {
				if (comp.compare(arr[i], arr[i+1]) > 0) {
					E tmp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = tmp;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		String[] a = new String[]{ "A", "E", "H", "Z", "Q", "R" };
		bubbleSort(a);
		for (String v : a) {
			System.out.print(v + " ");
		}
		System.out.println();
		
		Integer[] a2 = new Integer[]{ 3, 6, 4, 1, 8, 7 };
		bubbleSort(a2);
		for (Integer v : a2) {
			System.out.print(v + " ");
		}
		System.out.println();
		
		Integer[] a3 = new Integer[]{ 3, 6, 4, 1, 8, 7 };
		bubbleSort(a3, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}
		});
		for (Integer v : a3) {
			System.out.print(v + " ");
		}
		System.out.println();
		
		Integer[] a4 = new Integer[]{ 3, 6, 4, 1, 8, 7 };
		bubbleSort(a4, Collections.reverseOrder());
		for (Integer v : a4) {
			System.out.print(v + " ");
		}
		System.out.println();
		
		Integer[] a5 = new Integer[]{ 3, 6, 4, 1, 8, 7 };
		bubbleSort(a5, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				if (o1 % 2 == 0 && o2 % 2 == 1) {
					return -1;
				} else if (o1 % 2 == 1 && o2 % 2 == 0) {
					return 1;
				} else {
					return o1.compareTo(o2);
				}
			}
		});
		for (Integer v : a5) {
			System.out.print(v + " ");
		}
		System.out.println();
	}
}

package edu.ycp.cs201.sort;

import java.util.Collections;
import java.util.Comparator;

// IMPORTANT: bubble sort is not an efficient sorting algorithm.
// We will see much more efficient sorting algorithms later
// in the course.

public class Sort {
	public static<E extends Comparable<E>> void bubbleSort(E[] arr) {
		for (int j = arr.length-1; j>0; j--) {
			for (int i = 0; i < j; i++) {
				E left = arr[i];
				E right = arr[i+1];
				if (left.compareTo(right) > 0) {
					// elements are out of order
					E tmp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = tmp;
				}
			}
		}
	}
	
	public static<E> void bubbleSort(E[] arr, Comparator<E> comp) {
		for (int j = arr.length-1; j>0; j--) {
			for (int i = 0; i < j; i++) {
				E left = arr[i];
				E right = arr[i+1];
				if (comp.compare(left, right) > 0) {
					// elements are out of order
					E tmp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = tmp;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		String[] a = new String[]{ "A", "E", "B", "Z", "J", "Y"  };
		bubbleSort(a);
		for (String s : a) {
			System.out.print(s + " ");
		}
		System.out.println();

		Integer[] a2 = new Integer[]{ 2, 6, 3, 7, 11, 78, 43};
		bubbleSort(a2);
		for (Integer i : a2) {
			System.out.print(i + " ");
		}
		System.out.println();

		Integer[] a3 = new Integer[]{ 2, 6, 3, 7, 11, 78, 43};
		bubbleSort(a3, new Comparator<Integer>() {
			@Override
			public int compare(Integer o1, Integer o2) {
				return o1.compareTo(o2);
			}
		});
		for (Integer i : a3) {
			System.out.print(i + " ");
		}
		System.out.println();

		Integer[] a4 = new Integer[]{ 2, 6, 3, 7, 11, 78, 43};
		bubbleSort(a4, Collections.reverseOrder());
		for (Integer i : a4) {
			System.out.print(i + " ");
		}
		
		System.out.println();
	}
}

package edu.ycp.cs201.inheritance;

public enum Terrain {
	ROAD,
	AIRPORT,
	WATER,
	MARINA,
	FIELD,
	FOREST,
	MOUNTAIN;
}

package edu.ycp.cs201.inheritance;

public class Boat extends Vehicle {
	
	public Boat(double maxSpeed) {
		super(maxSpeed);
	}

	@Override
	public boolean startTrip(Terrain t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean endTrip(Terrain t) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean move(Terrain t) {
		// TODO Auto-generated method stub
		return false;
	}

}

package edu.ycp.cs201.cards;

public enum Rank {
	// TODO - add rank values
}

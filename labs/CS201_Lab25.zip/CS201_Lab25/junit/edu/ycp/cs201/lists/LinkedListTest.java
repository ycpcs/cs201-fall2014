package edu.ycp.cs201.lists;

import java.util.Iterator;

import junit.framework.TestCase;

public class LinkedListTest extends TestCase {
	private LinkedList<Integer> empty;
	private LinkedList<String> names;
	private LinkedList<Integer> nums;

	@Override
	protected void setUp() throws Exception {
		empty = new LinkedList<Integer>();

		names = new LinkedList<String>();
		names.add("Alice");
		names.add("Bob");
		names.add("Carl");
		names.add("Delores");

		nums = new LinkedList<Integer>();
	}

	public void testSize() throws Exception {
		assertEquals(0, empty.size());
		assertEquals(4, names.size());

	}

	public void testGet() throws Exception {
		assertEquals("Alice", names.get(0));
		assertEquals("Bob", names.get(1));
		assertEquals("Carl", names.get(2));
		assertEquals("Delores", names.get(3));
	}

	public void testSet() throws Exception {
		names.set(2, "Cornelius");
		assertEquals("Cornelius", names.get(2));
	}

	public void testGrow() throws Exception {
		names.add("Eli");
		assertEquals(5, names.size());
		testGet();
		assertEquals("Eli", names.get(4));
	}

	public void testGrowLarge() throws Exception {
		for (int i = 0; i < 1000000; i++) {
			nums.add((Integer) i);
		}
		assertEquals(1000000, nums.size());
	}

	public void testRemove() throws Exception {
		String s = names.remove(2);
		assertEquals("Carl", s);
		assertEquals(3, names.size());
		assertEquals("Alice", names.get(0));
		assertEquals("Bob", names.get(1));
		assertEquals("Delores", names.get(2));
	}

	public void testIterator() throws Exception {
		Iterator<String> i = names.iterator();

		// verify that all of the values in the collection
		// can be accessed through the Iterator
		assertTrue(i.hasNext());
		assertEquals("Alice", i.next());
		assertTrue(i.hasNext());
		assertEquals("Bob", i.next());
		assertTrue(i.hasNext());
		assertEquals("Carl", i.next());
		assertTrue(i.hasNext());
		assertEquals("Delores", i.next());

		// We've seen all of the values -
		// now hasNext() should return false
		assertFalse(i.hasNext());
	}

	public void testIteratorRemove() throws Exception {
		Iterator<String> i = names.iterator();

		assertEquals("Alice", i.next());
		assertEquals("Bob", i.next());

		// remove "Carl"
		assertEquals("Carl", i.next());
		i.remove();

		// the next element should be "Delores"
		assertEquals("Delores", i.next());

		// Iterator is now at the end of the collection
		assertFalse(i.hasNext());

		// Check to ensure that the removed element is really gone
		assertEquals(3, names.size());
		i = names.iterator();
		
		assertEquals("Alice", i.next());
		assertEquals("Bob", i.next());
		assertEquals("Delores", i.next());
		assertFalse(i.hasNext());
	}
}

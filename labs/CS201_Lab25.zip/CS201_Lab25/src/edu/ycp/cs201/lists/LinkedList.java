package edu.ycp.cs201.lists;

import java.util.Iterator;

public class LinkedList<E> {
	private LinkedListNode<E> head, tail;
	
	public LinkedList() {
		head = null;
		tail = null;
	}
	
	public int size() {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	public void add(E value) {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	public E get(int index) {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	public void set(int index, E value) {
		throw new UnsupportedOperationException("Not implemented yet");
	}
	
	public E remove(int index) {
		throw new UnsupportedOperationException("Not implemented yet");
	}

	public Iterator<E> iterator() {
		return new LinkedListIterator<E>(head);
	}
	
}
